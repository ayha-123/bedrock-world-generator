from pathlib import Path
import shutil
import sys

seed = sys.argv[1] if len(sys.argv) > 1 else "123456"
world_size = sys.argv[2] if len(sys.argv) > 2 else "10000"

src = Path("generated_pack")
dst = Path("generated_pack_runtime")

if dst.exists():
    shutil.rmtree(dst)

shutil.copytree(src, dst)

print(f"V5 test pack prepared: seed={seed}, world_size={world_size}")
