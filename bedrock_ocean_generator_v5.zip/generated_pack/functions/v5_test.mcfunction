scoreboard objectives add oi_v5 dummy
execute as @a unless score @s oi_v5 matches 1 run tellraw @s {"rawtext":[{"text":"§eOcean Islands Generator V5 data pack is active."}]}
execute as @a unless score @s oi_v5 matches 1 run scoreboard players set @s oi_v5 1
