import { world, system } from "@minecraft/server";

const MESSAGE = "§bOcean Islands Generator V5 Script API is active.";
const TEST_BLOCK = "minecraft:gold_block";
const seen = new Set();

function testPlayer(player) {
    if (!player) return;

    const id = player.name;
    if (!seen.has(id)) {
        seen.add(id);
        try {
            player.sendMessage(MESSAGE);
            const dim = player.dimension;
            const x = Math.floor(player.location.x) + 3;
            const y = Math.floor(player.location.y);
            const z = Math.floor(player.location.z);
            dim.setBlockType({ x, y, z }, TEST_BLOCK);
            player.sendMessage("§aV5 script test block placed at +3 X.");
        } catch (error) {
            player.sendMessage("§cV5 script error: " + String(error));
        }
    }
}

system.runInterval(() => {
    try {
        for (const player of world.getPlayers()) {
            testPlayer(player);
        }
    } catch (error) {}
}, 20);
