# Bedrock Ocean Islands Generator V5 Test

This version is a diagnostic pack for Minecraft Bedrock 26.52.

It targets the stable @minecraft/server 2.10.0 API used by the 26.50+ release line.

The test has two independent checks:

1. A data-pack tick function should display a V5 data-pack message.
2. The JavaScript Script API should display a V5 Script API message and place one gold block three blocks east of the player.

Do not judge the ocean/island generation from this version. This version only proves that the behavior pack and Script API are executing correctly before the full generator is restored.
