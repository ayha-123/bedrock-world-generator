Ocean Islands Generator V2

Uses the supplied Bedrock template only as a valid world container.
When explored, the behavior pack clears old terrain in the active region, creates a connected ocean layer, then creates deterministic islands, villages, roads, farms, trees and resources from the selected seed.
