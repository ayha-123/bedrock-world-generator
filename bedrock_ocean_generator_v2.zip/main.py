import os
import shutil
import sys

seed = int(sys.argv[1])
world_size = int(sys.argv[2])

src = "generated_pack"
dst = "generated_pack_runtime"

if os.path.exists(dst):
    shutil.rmtree(dst)

shutil.copytree(src, dst)

path = os.path.join(dst, "scripts", "main.js")
text = open(path, encoding="utf-8").read()
text = text.replace("const SEED = 123456;", f"const SEED = {seed};")
text = text.replace("const WORLD_SIZE = 10000;", f"const WORLD_SIZE = {world_size};")
open(path, "w", encoding="utf-8").write(text)

print("SEED:", seed)
print("WORLD SIZE:", world_size)
print("OCEAN-FIRST GENERATOR READY")
