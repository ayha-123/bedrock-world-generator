import { world, system, BlockVolume } from "@minecraft/server";

const SEED = 123456;
const WORLD_SIZE = 10000;

const ORIGIN_X = 73;
const ORIGIN_Z = 256;
const SEA_Y = 62;
const OCEAN_FLOOR = 48;
const GRID = 220;
const ACTIVE_RADIUS = 1;

const built = new Set();
const clearing = new Set();

function hash(x, z, salt = 0) {
    let h = Math.imul((x + salt * 101) | 0, 374761393);
    h ^= Math.imul((z - salt * 67) | 0, 668265263);
    h ^= SEED | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return (h ^ (h >>> 16)) >>> 0;
}

function r01(x, z, salt) {
    return (hash(x, z, salt) % 1000000) / 1000000;
}

function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
}

function fill(dim, x1, y1, z1, x2, y2, z2, block) {
    try {
        dim.fillBlocks(
            new BlockVolume(
                { x: Math.min(x1, x2), y: Math.min(y1, y2), z: Math.min(z1, z2) },
                { x: Math.max(x1, x2), y: Math.max(y1, y2), z: Math.max(z1, z2) }
            ),
            block,
            { ignoreChunkBoundErrors: true }
        );
    } catch (e) {}
}

function islandInfo(gx, gz) {
    const h = hash(gx, gz, 3);
    const roll = h % 100;

    let radius;
    let village;

    if (roll < 25) {
        radius = 14 + (h % 8);
        village = 0;
    } else if (roll < 78) {
        radius = 25 + (h % 12);
        village = 1;
    } else {
        radius = 42 + (h % 24);
        village = 2;
    }

    const jx = Math.floor((r01(gx, gz, 1) - 0.5) * 70);
    const jz = Math.floor((r01(gx, gz, 2) - 0.5) * 70);

    return {
        x: ORIGIN_X + gx * GRID + jx,
        z: ORIGIN_Z + gz * GRID + jz,
        radius,
        village
    };
}

function clearOldTerrain(dim, cx, cz, radius) {
    const r = radius + 28;
    fill(dim, cx - r, 0, cz - r, cx + r, 90, cz + r, "minecraft:air");
    fill(dim, cx - r, OCEAN_FLOOR, cz - r, cx + r, SEA_Y, cz + r, "minecraft:water");
}

function makeIsland(dim, cx, cz, radius, gx, gz) {
    const beach = radius + 2;

    for (let z = -beach; z <= beach; z++) {
        const span = Math.floor(Math.sqrt(Math.max(0, beach * beach - z * z)));
        const wave = Math.floor(r01(gx + z, gz - z, 9) * 3);

        fill(
            dim,
            cx - span,
            OCEAN_FLOOR,
            cz + z,
            cx + span,
            SEA_Y,
            cz + z,
            "minecraft:water"
        );

        const landSpan = Math.max(0, span - 2 - wave);

        if (landSpan > 0) {
            const h = 64 + Math.floor(r01(gx + z, gz + z, 12) * 5);

            fill(
                dim,
                cx - landSpan,
                OCEAN_FLOOR,
                cz + z,
                cx + landSpan,
                h - 1,
                cz + z,
                "minecraft:dirt"
            );

            fill(
                dim,
                cx - landSpan,
                h,
                cz + z,
                cx + landSpan,
                h,
                cz + z,
                "minecraft:grass_block"
            );
        }
    }
}

function tree(dim, x, y, z) {
    fill(dim, x, y, z, x, y + 4, z, "minecraft:oak_log");
    fill(dim, x - 2, y + 3, z - 2, x + 2, y + 5, z + 2, "minecraft:oak_leaves");
    fill(dim, x - 1, y + 6, z - 1, x + 1, y + 6, z + 1, "minecraft:oak_leaves");
}

function placeTrees(dim, cx, cz, radius, gx, gz) {
    const count = Math.max(3, Math.floor(radius / 5));

    for (let i = 0; i < count; i++) {
        const angle = r01(gx, gz, 30 + i) * Math.PI * 2;
        const dist = 5 + r01(gx, gz, 60 + i) * Math.max(3, radius - 8);
        const x = Math.floor(cx + Math.cos(angle) * dist);
        const z = Math.floor(cz + Math.sin(angle) * dist);
        const y = 65 + Math.floor(r01(gx, gz, 90 + i) * 3);
        tree(dim, x, y, z);
    }
}

function house(dim, x, y, z, w, d, h, roofBlock) {
    fill(dim, x, y, z, x + w, y + h, z + d, "minecraft:oak_planks");
    fill(dim, x + 1, y + 1, z + 1, x + w - 1, y + h - 1, z + d - 1, "minecraft:air");

    fill(dim, x + 1, y + 2, z, x + w - 1, y + 3, z, "minecraft:glass");
    fill(dim, x + Math.floor(w / 2), y + 1, z + d, x + Math.floor(w / 2) + 1, y + 3, z + d, "minecraft:air");

    for (let layer = 0; layer < 3; layer++) {
        const shrink = layer;
        fill(
            dim,
            x - 1 + shrink,
            y + h + layer,
            z - 1 + shrink,
            x + w + 1 - shrink,
            y + h + layer,
            z + d + 1 - shrink,
            roofBlock
        );
    }

    fill(dim, x + 2, y + 1, z + 1, x + 3, y + 1, z + 2, "minecraft:crafting_table");
    fill(dim, x + w - 2, y + 1, z + 1, x + w - 1, y + 1, z + 2, "minecraft:chest");
}

function farm(dim, x, y, z) {
    fill(dim, x, y, z, x + 8, y, z + 6, "minecraft:farmland");
    fill(dim, x + 1, y + 1, z + 1, x + 7, y + 1, z + 5, "minecraft:wheat");
    fill(dim, x + 3, y, z - 1, x + 4, y, z + 7, "minecraft:water");
}

function well(dim, x, y, z) {
    fill(dim, x - 2, y, z - 2, x + 2, y, z + 2, "minecraft:cobblestone");
    fill(dim, x - 1, y + 1, z - 1, x + 1, y + 2, z + 1, "minecraft:water");
    fill(dim, x - 2, y + 1, z - 2, x + 2, y + 1, z - 2, "minecraft:oak_fence");
    fill(dim, x - 2, y + 1, z + 2, x + 2, y + 1, z + 2, "minecraft:oak_fence");
    fill(dim, x - 2, y + 1, z - 2, x - 2, y + 1, z + 2, "minecraft:oak_fence");
    fill(dim, x + 2, y + 1, z - 2, x + 2, y + 1, z + 2, "minecraft:oak_fence");
}

function road(dim, x1, z1, x2, z2) {
    const steps = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1));
    for (let i = 0; i <= steps; i++) {
        const t = steps === 0 ? 0 : i / steps;
        const x = Math.floor(x1 + (x2 - x1) * t);
        const z = Math.floor(z1 + (z2 - z1) * t);
        fill(dim, x - 1, 65, z - 1, x + 1, 65, z + 1, "minecraft:path");
    }
}

function buildVillage(dim, cx, cz, radius, type, gx, gz) {
    const count = type === 0 ? 3 : type === 1 ? 7 : 12;
    const roof = type === 2 ? "minecraft:spruce_planks" : "minecraft:oak_planks";

    well(dim, cx, 65, cz);

    for (let i = 0; i < count; i++) {
        const angle = r01(gx, gz, 200 + i) * Math.PI * 2;
        const dist = 8 + r01(gx, gz, 230 + i) * Math.max(5, radius - 10);
        const x = Math.floor(cx + Math.cos(angle) * dist);
        const z = Math.floor(cz + Math.sin(angle) * dist);

        const w = 5 + (i % 3);
        const d = 5 + ((i + 1) % 3);
        const h = 4 + (i % 2);

        road(dim, cx, cz, x, z);
        house(dim, x, 65, z, w, d, h, roof);
    }

    if (type >= 1) {
        farm(dim, cx + 9, 65, cz - 5);
        farm(dim, cx - 17, 65, cz + 7);
    }

    if (type === 2) {
        fill(dim, cx - 5, 65, cz - 5, cx + 5, 69, cz + 5, "minecraft:stone_bricks");
        fill(dim, cx - 3, 70, cz - 3, cx + 3, 70, cz + 3, "minecraft:gold_block");
        fill(dim, cx - 1, 71, cz - 1, cx + 1, 75, cz + 1, "minecraft:oak_log");
    }
}

function buildRegion(dim, gx, gz) {
    const key = gx + ":" + gz;
    if (built.has(key) || clearing.has(key)) return;

    const info = islandInfo(gx, gz);

    if (Math.abs(info.x - ORIGIN_X) > WORLD_SIZE / 2 + GRID ||
        Math.abs(info.z - ORIGIN_Z) > WORLD_SIZE / 2 + GRID) {
        built.add(key);
        return;
    }

    clearing.add(key);

    clearOldTerrain(dim, info.x, info.z, info.radius);
    makeIsland(dim, info.x, info.z, info.radius, gx, gz);
    placeTrees(dim, info.x, info.z, info.radius, gx, gz);
    buildVillage(dim, info.x, info.z, info.radius, info.village, gx, gz);

    built.add(key);
    clearing.delete(key);
}

function tick() {
    const dim = world.getDimension("overworld");

    for (const player of world.getAllPlayers()) {
        const gx = Math.floor((player.location.x - ORIGIN_X) / GRID);
        const gz = Math.floor((player.location.z - ORIGIN_Z) / GRID);

        for (let x = gx - ACTIVE_RADIUS; x <= gx + ACTIVE_RADIUS; x++) {
            for (let z = gz - ACTIVE_RADIUS; z <= gz + ACTIVE_RADIUS; z++) {
                try {
                    buildRegion(dim, x, z);
                } catch (e) {}
            }
        }
    }
}

world.afterEvents.worldLoad.subscribe(() => {
    system.runInterval(tick, 20);
});
