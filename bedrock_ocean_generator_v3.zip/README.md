# Bedrock Ocean Islands Generator V3

GitHub Actions builds a Bedrock `.mcworld` containing the supplied template plus a behavior pack.

The behavior pack starts from `playerSpawn` instead of `worldLoad`, prints status messages, and generates nearby ocean regions around the player.

Inputs:
- Seed
- World Size

This version is designed for Bedrock mobile and GitHub-only use.
