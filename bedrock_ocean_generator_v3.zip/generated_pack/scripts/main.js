import { world, system, BlockVolume } from "@minecraft/server";

const SEED = 123456;
const WORLD_SIZE = 10000;

const ORIGIN_X = 73;
const ORIGIN_Z = 256;

const SEA_Y = 62;
const FLOOR_Y = 48;
const GRID = 220;
const ACTIVE_RADIUS = 1;

const built = new Set();
const queue = [];
let running = false;
let started = false;

function hash(x, z, salt = 0) {
    let h = Math.imul((x + salt * 101) | 0, 374761393);
    h ^= Math.imul((z - salt * 67) | 0, 668265263);
    h ^= SEED | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return (h ^ (h >>> 16)) >>> 0;
}

function r01(x, z, salt) {
    return (hash(x, z, salt) % 1000000) / 1000000;
}

function fill(dim, a, b, c, d, e, f, block) {
    try {
        dim.fillBlocks(
            new BlockVolume(
                { x: Math.min(a, d), y: Math.min(b, e), z: Math.min(c, f) },
                { x: Math.max(a, d), y: Math.max(b, e), z: Math.max(c, f) }
            ),
            block,
            { ignoreChunkBoundErrors: true }
        );
        return true;
    } catch (error) {
        return false;
    }
}

function safeMessage(player, text) {
    try {
        player.sendMessage(text);
    } catch (error) {}
}

function islandInfo(gx, gz) {
    const h = hash(gx, gz, 3);
    const roll = h % 100;
    let radius;
    let village;

    if (roll < 25) {
        radius = 14 + (h % 8);
        village = 0;
    } else if (roll < 78) {
        radius = 25 + (h % 12);
        village = 1;
    } else {
        radius = 42 + (h % 24);
        village = 2;
    }

    return {
        x: ORIGIN_X + gx * GRID + Math.floor((r01(gx, gz, 1) - 0.5) * 70),
        z: ORIGIN_Z + gz * GRID + Math.floor((r01(gx, gz, 2) - 0.5) * 70),
        radius,
        village
    };
}

function clearChunkColumn(dim, cx, cz) {
    const x1 = cx * 16;
    const z1 = cz * 16;
    const x2 = x1 + 15;
    const z2 = z1 + 15;

    fill(dim, x1, 0, z1, x2, 160, z2, "minecraft:air");
    fill(dim, x1, FLOOR_Y, z1, x2, SEA_Y, z2, "minecraft:water");
}

function makeIsland(dim, cx, cz, radius, gx, gz) {
    const r = radius + 2;

    for (let z = -r; z <= r; z++) {
        const span = Math.floor(Math.sqrt(Math.max(0, r * r - z * z)));
        const edge = Math.max(0, span - 2 - Math.floor(r01(gx + z, gz - z, 9) * 3));

        if (edge <= 0) continue;

        const h = 64 + Math.floor(r01(gx + z, gz + z, 12) * 5);

        fill(dim, cx - edge, FLOOR_Y, cz + z, cx + edge, h - 1, cz + z, "minecraft:dirt");
        fill(dim, cx - edge, h, cz + z, cx + edge, h, cz + z, "minecraft:grass_block");
    }
}

function tree(dim, x, y, z) {
    fill(dim, x, y, z, x, y + 4, z, "minecraft:oak_log");
    fill(dim, x - 2, y + 3, z - 2, x + 2, y + 5, z + 2, "minecraft:oak_leaves");
    fill(dim, x - 1, y + 6, z - 1, x + 1, y + 6, z + 1, "minecraft:oak_leaves");
}

function placeTrees(dim, cx, cz, radius, gx, gz) {
    const count = Math.max(3, Math.floor(radius / 5));

    for (let i = 0; i < count; i++) {
        const angle = r01(gx, gz, 30 + i) * Math.PI * 2;
        const dist = 6 + r01(gx, gz, 60 + i) * Math.max(3, radius - 10);
        const x = Math.floor(cx + Math.cos(angle) * dist);
        const z = Math.floor(cz + Math.sin(angle) * dist);
        tree(dim, x, 65, z);
    }
}

function house(dim, x, y, z, w, d, h, roof) {
    fill(dim, x, y, z, x + w, y + h, z + d, "minecraft:oak_planks");
    fill(dim, x + 1, y + 1, z + 1, x + w - 1, y + h - 1, z + d - 1, "minecraft:air");
    fill(dim, x + 1, y + 2, z, x + w - 1, y + 3, z, "minecraft:glass");
    fill(dim, x + Math.floor(w / 2), y + 1, z + d, x + Math.floor(w / 2) + 1, y + 3, z + d, "minecraft:air");

    for (let layer = 0; layer < 3; layer++) {
        fill(
            dim,
            x - 1 + layer, y + h + layer, z - 1 + layer,
            x + w + 1 - layer, y + h + layer, z + d + 1 - layer,
            roof
        );
    }

    fill(dim, x + 2, y + 1, z + 1, x + 2, y + 1, z + 1, "minecraft:crafting_table");
    fill(dim, x + w - 2, y + 1, z + 1, x + w - 2, y + 1, z + 1, "minecraft:chest");
}

function road(dim, x1, z1, x2, z2) {
    const steps = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1));
    for (let i = 0; i <= steps; i++) {
        const t = steps === 0 ? 0 : i / steps;
        const x = Math.floor(x1 + (x2 - x1) * t);
        const z = Math.floor(z1 + (z2 - z1) * t);
        fill(dim, x - 1, 65, z - 1, x + 1, 65, z + 1, "minecraft:path");
    }
}

function well(dim, x, y, z) {
    fill(dim, x - 2, y, z - 2, x + 2, y, z + 2, "minecraft:cobblestone");
    fill(dim, x - 1, y + 1, z - 1, x + 1, y + 1, z + 1, "minecraft:water");
    fill(dim, x - 2, y + 1, z - 2, x + 2, y + 1, z - 2, "minecraft:oak_fence");
    fill(dim, x - 2, y + 1, z + 2, x + 2, y + 1, z + 2, "minecraft:oak_fence");
    fill(dim, x - 2, y + 1, z - 2, x - 2, y + 1, z + 2, "minecraft:oak_fence");
    fill(dim, x + 2, y + 1, z - 2, x + 2, y + 1, z + 2, "minecraft:oak_fence");
}

function buildVillage(dim, cx, cz, radius, type, gx, gz) {
    const count = type === 0 ? 3 : type === 1 ? 7 : 12;
    const roof = type === 2 ? "minecraft:spruce_planks" : "minecraft:oak_planks";

    well(dim, cx, 65, cz);

    for (let i = 0; i < count; i++) {
        const angle = r01(gx, gz, 200 + i) * Math.PI * 2;
        const dist = 8 + r01(gx, gz, 230 + i) * Math.max(5, radius - 12);
        const x = Math.floor(cx + Math.cos(angle) * dist);
        const z = Math.floor(cz + Math.sin(angle) * dist);
        const w = 5 + (i % 3);
        const d = 5 + ((i + 1) % 3);
        const h = 4 + (i % 2);

        road(dim, cx, cz, x, z);
        house(dim, x, 65, z, w, d, h, roof);
    }

    if (type >= 1) {
        fill(dim, cx + 9, 65, cz - 5, cx + 17, 65, cz + 1, "minecraft:farmland");
        fill(dim, cx + 10, 66, cz - 4, cx + 16, 66, cz, "minecraft:wheat");
        fill(dim, cx - 17, 65, cz + 7, cx - 9, 65, cz + 13, "minecraft:farmland");
        fill(dim, cx - 16, 66, cz + 8, cx - 10, 66, cz + 12, "minecraft:wheat");
    }

    if (type === 2) {
        fill(dim, cx - 5, 65, cz - 5, cx + 5, 69, cz + 5, "minecraft:stone_bricks");
        fill(dim, cx - 3, 70, cz - 3, cx + 3, 70, cz + 3, "minecraft:gold_block");
    }
}

function queueRegion(gx, gz, player) {
    const key = gx + ":" + gz;
    if (built.has(key) || queue.some(q => q.key === key)) return;

    const info = islandInfo(gx, gz);
    if (
        Math.abs(info.x - ORIGIN_X) > WORLD_SIZE / 2 + GRID ||
        Math.abs(info.z - ORIGIN_Z) > WORLD_SIZE / 2 + GRID
    ) {
        built.add(key);
        return;
    }

    queue.push({ key, gx, gz, info, player });
}

function buildRegion(item) {
    const dim = world.getDimension("overworld");
    const { key, gx, gz, info, player } = item;

    safeMessage(player, "§7Ocean generator: preparing region " + key);

    const minChunkX = Math.floor((info.x - info.radius - 24) / 16);
    const maxChunkX = Math.floor((info.x + info.radius + 24) / 16);
    const minChunkZ = Math.floor((info.z - info.radius - 24) / 16);
    const maxChunkZ = Math.floor((info.z + info.radius + 24) / 16);

    for (let cx = minChunkX; cx <= maxChunkX; cx++) {
        for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
            clearChunkColumn(dim, cx, cz);
        }
    }

    makeIsland(dim, info.x, info.z, info.radius, gx, gz);
    placeTrees(dim, info.x, info.z, info.radius, gx, gz);
    buildVillage(dim, info.x, info.z, info.radius, info.village, gx, gz);

    built.add(key);
    safeMessage(player, "§aOcean generator: region " + key + " complete");
}

function startForPlayer(player) {
    if (!started) {
        started = true;
        safeMessage(player, "§bOcean Islands Generator V3 is active.");
    }

    const gx = Math.floor((player.location.x - ORIGIN_X) / GRID);
    const gz = Math.floor((player.location.z - ORIGIN_Z) / GRID);

    for (let x = gx - ACTIVE_RADIUS; x <= gx + ACTIVE_RADIUS; x++) {
        for (let z = gz - ACTIVE_RADIUS; z <= gz + ACTIVE_RADIUS; z++) {
            queueRegion(x, z, player);
        }
    }
}

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    system.runTimeout(() => startForPlayer(player), 10);
});

system.runInterval(() => {
    if (running || queue.length === 0) return;

    running = true;
    const item = queue.shift();

    try {
        buildRegion(item);
    } catch (error) {
        safeMessage(item.player, "§cOcean generator error in region " + item.key);
    }

    running = false;
}, 40);
