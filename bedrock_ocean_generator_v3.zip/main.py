from pathlib import Path
import shutil
import sys

seed = sys.argv[1] if len(sys.argv) > 1 else "123456"
world_size = sys.argv[2] if len(sys.argv) > 2 else "10000"

src = Path("generated_pack")
dst = Path("generated_pack_runtime")

if dst.exists():
    shutil.rmtree(dst)

shutil.copytree(src, dst)

main_js = dst / "scripts" / "main.js"
text = main_js.read_text()
text = text.replace("const SEED = 123456;", f"const SEED = {int(seed)};")
text = text.replace("const WORLD_SIZE = 10000;", f"const WORLD_SIZE = {int(world_size)};")
main_js.write_text(text)

print(f"Generator prepared: seed={seed}, world_size={world_size}")
